public class TempStorageService
{
    public StorageConfig Config { get; set; } = new();
}