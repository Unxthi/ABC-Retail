using System.ComponentModel.DataAnnotations;

public class StorageConfig
{
    [Required]
    public string AccountName { get; set; }

    [Required]
    public string AccessKey { get; set; }
}