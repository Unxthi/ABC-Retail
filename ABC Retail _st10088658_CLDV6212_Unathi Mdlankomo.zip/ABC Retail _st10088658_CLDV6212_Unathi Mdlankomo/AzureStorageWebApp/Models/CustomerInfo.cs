﻿using Azure;
using Azure.Data.Tables;
using System.ComponentModel.DataAnnotations;

namespace AzureStorageWebApp.Models
{
    public class CustomerInfo : ITableEntity
    {
        
        
            public string PartitionKey { get; set; }
            public string RowKey { get; set; }
            public string? FirstName { get; set; }
            public string? Surname { get; set; }
            public string? Email { get; set; }
            public string? Phone { get; set; }
            public int? Age { get; set; }
            public string? Address { get; set; }
            public string? ContactMethod { get; set; }
            public DateTimeOffset? Timestamp { get; set; }
            public ETag ETag { get; set; }
        }
}
