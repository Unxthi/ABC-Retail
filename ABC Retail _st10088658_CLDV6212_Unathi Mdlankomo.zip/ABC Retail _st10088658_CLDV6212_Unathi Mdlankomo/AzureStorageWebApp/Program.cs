﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Azure.Storage.Blobs;
using Azure.Data.Tables;
using Azure.Storage.Queues;
using Azure.Storage.Files.Shares;

var builder = WebApplication.CreateBuilder(args);

// ✅ Register Razor Pages
builder.Services.AddRazorPages();

// ✅ Read the connection string from appsettings.json
var conn = builder.Configuration.GetConnectionString("AzureStorage");

if (string.IsNullOrEmpty(conn))
{
    throw new InvalidOperationException("Azure Storage connection string is missing. Check appsettings.json or App Service settings.");
}

// ✅ Register Azure clients in DI (Dependency Injection)
builder.Services.AddSingleton(new BlobServiceClient(conn));
builder.Services.AddSingleton(new TableServiceClient(conn));
builder.Services.AddSingleton(new QueueServiceClient(conn));
builder.Services.AddSingleton(new ShareServiceClient(conn));

var app = builder.Build();

// ✅ Use developer or production error handling
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}
else
{
    app.UseDeveloperExceptionPage();
}

app.UseStaticFiles();
app.UseRouting();
app.MapRazorPages();

app.Run();

