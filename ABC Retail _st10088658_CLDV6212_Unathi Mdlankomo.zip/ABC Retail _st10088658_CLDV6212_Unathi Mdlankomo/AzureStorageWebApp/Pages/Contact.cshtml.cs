using Azure.Data.Tables;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using AzureStorageWebApp.Models; // your CustomerInfo model
using System;
using System.Threading.Tasks;

namespace AzureStorageWebApp.Pages
{
    public class ContactModel : PageModel
    {
        private readonly TableServiceClient _tableSvc;

        public ContactModel(TableServiceClient tableSvc)
        {
            _tableSvc = tableSvc;
        }

        [BindProperty]
        public CustomerInfo Customer { get; set; }

        public void OnGet()
        {
            // Page load GET
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Get a reference to the 'Customers' table (create if it doesn�t exist)
            TableClient tableClient = _tableSvc.GetTableClient("Customers");
            await tableClient.CreateIfNotExistsAsync();

            // Set required PartitionKey + RowKey
            Customer.PartitionKey = "Customer";
            Customer.RowKey = Guid.NewGuid().ToString();

            // Save entity
            await tableClient.AddEntityAsync(Customer);

            TempData["Message"] = "Customer info saved successfully!";
            return RedirectToPage(); // reload page
        }
    }
}
