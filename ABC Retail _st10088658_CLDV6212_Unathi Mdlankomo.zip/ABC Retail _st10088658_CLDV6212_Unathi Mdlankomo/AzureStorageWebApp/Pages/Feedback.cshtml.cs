using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AzureStorageWebApp.Pages
{
    public class FeedbackModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
