using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

public class ConfigurationModel : PageModel
{
    [BindProperty]
    public StorageSettings StorageConfig { get; set; } = new();

    public string Message { get; set; } = string.Empty; // Initialize to avoid CS8618  

    public void OnPost()
    {
        if (ModelState.IsValid)
        {
            Message = "Configuration saved temporarily!";
            // You can store it in TempData or in-memory static class for now  
        }
    }

    public class StorageSettings
    {
        [Required]
        public string AccountName { get; set; }

        [Required]
        public string AccessKey { get; set; }
    }
}
