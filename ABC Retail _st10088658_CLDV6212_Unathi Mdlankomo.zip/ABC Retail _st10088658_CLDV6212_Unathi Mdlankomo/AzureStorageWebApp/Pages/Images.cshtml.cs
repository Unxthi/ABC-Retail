using Azure.Storage.Blobs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AzureStorageWebApp.Pages
{
    public class ImagesModel : PageModel
    {
        private readonly BlobServiceClient _blobSvc;

        public ImagesModel(BlobServiceClient blobSvc)
        {
            _blobSvc = blobSvc;
        }

        // This will hold blob names for listing
        public List<string> BlobNames { get; set; } = new();

        // Show the list of blobs when page loads
        public async Task OnGetAsync()
        {
            var container = _blobSvc.GetBlobContainerClient("product-images");
            await container.CreateIfNotExistsAsync();

            await foreach (var blob in container.GetBlobsAsync())
            {
                BlobNames.Add(blob.Name);
            }
        }

        // Upload file to Blob Storage
        public async Task<IActionResult> OnPostUploadAsync(IFormFile file, string blobName)
        {
            if (file == null || string.IsNullOrEmpty(blobName))
            {
                ModelState.AddModelError("", "File and blob name are required.");
                return Page();
            }

            var container = _blobSvc.GetBlobContainerClient("product-images");
            await container.CreateIfNotExistsAsync();

            var blob = container.GetBlobClient(blobName);
            using var stream = file.OpenReadStream();
            await blob.UploadAsync(stream, overwrite: true);

            // Reload blob list after upload
            return RedirectToPage();
        }
    }
}
